
@extends('admin.layouts.master',['navItem'=>'users'])
@section('title','Users Edit')
@section('content')

    <!--begin::Content container-->
    <div id="kt_app_content_container" class="app-container container-xxl">
        <!--end::Contact groups-->
        <!--begin::Content-->
        <div class="col-xl-12">
            <!--begin::Contacts-->
            <div class="card card-flush h-lg-100" id="kt_contacts_main">
                <!--begin::Card header-->
                <div class="card-header pt-7" id="kt_chat_contacts_header">
                    <!--begin::Card title-->
                    <div class="card-title">
                        <!--begin::Svg Icon | path: icons/duotune/communication/com005.svg-->
                        <span class="svg-icon svg-icon-1 me-2">
															<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																<path d="M20 14H18V10H20C20.6 10 21 10.4 21 11V13C21 13.6 20.6 14 20 14ZM21 19V17C21 16.4 20.6 16 20 16H18V20H20C20.6 20 21 19.6 21 19ZM21 7V5C21 4.4 20.6 4 20 4H18V8H20C20.6 8 21 7.6 21 7Z" fill="currentColor" />
																<path opacity="0.3" d="M17 22H3C2.4 22 2 21.6 2 21V3C2 2.4 2.4 2 3 2H17C17.6 2 18 2.4 18 3V21C18 21.6 17.6 22 17 22ZM10 7C8.9 7 8 7.9 8 9C8 10.1 8.9 11 10 11C11.1 11 12 10.1 12 9C12 7.9 11.1 7 10 7ZM13.3 16C14 16 14.5 15.3 14.3 14.7C13.7 13.2 12 12 10.1 12C8.10001 12 6.49999 13.1 5.89999 14.7C5.59999 15.3 6.19999 16 7.39999 16H13.3Z" fill="currentColor" />
															</svg>
														</span>
                        <!--end::Svg Icon-->
                        <h2>Edit User</h2>
                    </div>
                    <!--end::Card title-->
                </div>
                <!--end::Card header-->
                <!--begin::Card body-->
                <div class="card-body pt-5">
                    <!--begin::Form-->
                    <form id="kt_ecommerce_settings_general_form" method="POST" class="form" action="{{route('users.update', $user->id)}}">
                        @csrf
                        @method('PATCH')
                        <!--begin::Input group-->
{{--                        <div class="mb-7">--}}
{{--                            <!--begin::Label-->--}}
{{--                            <label class="fs-6 fw-semibold mb-3">--}}
{{--                                <span>Update Avatar</span>--}}
{{--                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="Allowed file types: png, jpg, jpeg."></i>--}}
{{--                            </label>--}}
{{--                            <!--end::Label-->--}}
{{--                            <!--begin::Image input wrapper-->--}}
{{--                            <div class="mt-1">--}}
{{--                                <!--begin::Image placeholder-->--}}
{{--                                <style>.image-input-placeholder { background-image: url('assets/media/svg/files/blank-image.svg'); } [data-theme="dark"] .image-input-placeholder { background-image: url('assets/media/svg/files/blank-image-dark.svg'); }</style>--}}
{{--                                <!--end::Image placeholder-->--}}
{{--                                <!--begin::Image input-->--}}
{{--                                <div class="image-input image-input-outline image-input-placeholder image-input-empty image-input-empty" data-kt-image-input="true">--}}
{{--                                    <!--begin::Preview existing avatar-->--}}
{{--                                    <div class="image-input-wrapper w-100px h-100px" style="background-image: url('')"></div>--}}
{{--                                    <!--end::Preview existing avatar-->--}}
{{--                                    <!--begin::Edit-->--}}
{{--                                    <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="change" data-bs-toggle="tooltip" title="Change avatar">--}}
{{--                                        <i class="bi bi-pencil-fill fs-7"></i>--}}
{{--                                        <!--begin::Inputs-->--}}
{{--                                        <input type="file" name="avatar" accept=".png, .jpg, .jpeg" />--}}
{{--                                        <input type="hidden" name="avatar_remove" />--}}
{{--                                        <!--end::Inputs-->--}}
{{--                                    </label>--}}
{{--                                    <!--end::Edit-->--}}
{{--                                    <!--begin::Cancel-->--}}
{{--                                    <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="cancel" data-bs-toggle="tooltip" title="Cancel avatar">--}}
{{--																		<i class="bi bi-x fs-2"></i>--}}
{{--																	</span>--}}
{{--                                    <!--end::Cancel-->--}}
{{--                                    <!--begin::Remove-->--}}
{{--                                    <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="remove" data-bs-toggle="tooltip" title="Remove avatar">--}}
{{--																		<i class="bi bi-x fs-2"></i>--}}
{{--																	</span>--}}
{{--                                    <!--end::Remove-->--}}
{{--                                </div>--}}
{{--                                <!--end::Image input-->--}}
{{--                            </div>--}}
{{--                            <!--end::Image input wrapper-->--}}
{{--                        </div>--}}
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="fv-row mb-7">
                            <!--begin::Label-->
                            <label class="fs-6 fw-semibold form-label mt-3">
                                <span class="required">Name</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="Enter the contact's name."></i>
                            </label>
                            <!--end::Label-->
                            <!--begin::Input-->
                            <input type="text" class="form-control form-control-solid" name="name" value="{{$user->name}}" />
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="fv-row mb-7">
                            <!--begin::Label-->
                            <label class="fs-6 fw-semibold form-label mt-3">
                                <span class="required">Email</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="Enter the contact's name."></i>
                            </label>
                            <!--end::Label-->
                            <!--begin::Input-->
                            <input type="email" disabled class="form-control form-control-solid" name="email" value="{{$user->email}}" />
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="fv-row mb-7">
                            <!--begin::Label-->
                            <label class="fs-6 fw-semibold form-label mt-3">
                                <span class="required">Password</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="Enter the password"></i>
                            </label>
                            <!--end::Label-->
                            <!--begin::Input-->
                            <input type="password" class="form-control form-control-solid" name="password" value="" />
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="fv-row mb-7">
                            <!--begin::Label-->
                            <label class="fs-6 fw-semibold form-label mt-3">
                                <span class="required">Role</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="Enter the contact's name."></i>
                            </label>
                            @foreach($roles as $role)
                                <!--begin::Input row-->
                                <div class="d-flex fv-row p-3">

                                    <!--begin::Radio-->
                                    <div class="form-check form-check-custom form-check-solid">
                                        <!--begin::Input-->
{{--                                        @dd($userRole)--}}
                                        <input class="form-check-input me-3" @if($userRole->id == $role->id) checked="checked" @endif name="roles"   type="radio" value="{{$role->id}}" id="kt_modal_update_role_option_0" checked='checked' />
                                        <!--end::Input-->
                                        <!--begin::Label-->
                                        <label class="form-check-label" for="kt_modal_update_role_option_0">
                                            <div class="fw-bold text-gray-800">{{$role->name}}</div>
                                            {{--                                                            <div class="text-gray-600">Best for business owners and company administrators</div>--}}
                                        </label>
                                        <!--end::Label-->
                                    </div>

                                    <!--end::Radio-->
                                </div>
                            @endforeach
                            <!--end::Label-->
                        </div>
                        <!--end::Input group-->

                        <!--begin::Separator-->
                        <div class="separator mb-6"></div>
                        <!--end::Separator-->
                        <!--begin::Action buttons-->
                        <div class="d-flex justify-content-end">
                            <!--begin::Button-->
{{--                            <button type="reset" data-kt-contacts-type="cancel" class="btn btn-light me-3">Cancel</button>--}}
                            <!--end::Button-->
                            <!--begin::Button-->
                            <button type="submit"
{{--                                    data-kt-contacts-type="submit"--}}
                                    class="btn btn-primary">
                                <span class="indicator-label">Save</span>
                                <span class="indicator-progress">Please wait...
																<span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                            <!--end::Button-->
                        </div>
                        <!--end::Action buttons-->
                    </form>
                    <!--end::Form-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Contacts-->
        </div>
        <!--end::Content-->
        <!--begin::Content-->
    </div>
@endsection
